package com.example.asus.proto5phase3.Database.Model;

public class RequestedTrips {
    public static final String TABLE_NAME = "requestedtrips_table";

    public static final String COL_id="id";
    public static final String COL_trip="trip";
    public static final String COL_driver="driver";
    public static final String COL_requestedUser=" requestedUser";
    public static final String COL_isAccepted ="isAccepted";


    private int id;
    private String trip;
    private String driver;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTrip() {
        return trip;
    }

    public void setTrip(String trip) {
        this.trip = trip;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public String getRequestedUser() {
        return requestedUser;
    }

    public void setRequestedUser(String requestedUser) {
        this.requestedUser = requestedUser;
    }

    public String getIsAccepetd() {
        return isAccepetd;
    }

    public void setIsAccepetd(String isAccepetd) {
        this.isAccepetd = isAccepetd;
    }

    private String requestedUser;
    private String isAccepetd;




    public static final String CREATE_TABLE =
            "CREATE TABLE " + TABLE_NAME + "("
                    + COL_id + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COL_trip + "TEXT,"
                    + COL_driver + " TEXT,"
                    + COL_requestedUser + " TEXT,"
                    + COL_isAccepted + "TEXT"
                    + ")";
    public RequestedTrips (String trip, String driver, String requestedUser, String isAccepetd){
        this.trip=trip;
        this.driver=driver;
        this.requestedUser=requestedUser;
        this.isAccepetd=isAccepetd;

    }

}
